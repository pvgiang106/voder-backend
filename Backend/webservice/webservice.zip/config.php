<?php

define('DB_USER',"voderadmin");
define('DB_PASSWORD',"admin123");
define('DB_DATABASE',"voder_backend");
define('DB_SERVER',"localhost");
define('BASE_PATH', "http://www.appsun.com.au/voderbackend/")
?>
